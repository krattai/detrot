﻿###################################################
#                                                 #    
#       Readme for via driver package		  #
#                                                 #
###################################################

This driver is for Ubuntu 8.04 LTS Desktop Edition.

Installation and Uninstallation
===============================
1. How to Install/Uninstall the via Linux Driver 

   1.1 to uncompress the via driver package

         tar zxvf ./via-unichrome.83.40692.tar.gz

   1.2 to install the driver

         cd   ./via-unichrome.83.40692

         sudo ./vinstall

   1.3 to uninstall the driver

         cd   ./via-unichrome.83.40692
         sudo ./unvinstall

2. How to enable 3D desktop effects / Compiz after VIA driver has been installed

   2.1 edit the compiz script file

         sudo vi /usr/bin/compiz

   2.2 find the line

         WHITELIST="nvidia intel ati radeon i810"

   2.3 add “via” to the list to make it

         WHITELIST="nvidia intel ati radeon i810 via"

   2.3  save then restart x-server (<Ctl> + <Alt> + <Backspace>)
